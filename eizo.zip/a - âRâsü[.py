import pandas as pd
from func import *

df_master = pd.read_excel('型名マスタ.xlsx')

sTgtFile = '日程一覧表A.xlsx'

df_nittei = pd.read_excel(sTgtFile)  # 日程一覧表をdfへ取り込み
df_nittei = df_nittei.fillna('')
df_nittei_back = df_nittei.copy()    # 処理前バックアップ 

col_cal = 13 -1   # -1はExcel列とdf列の調整
row_cal = 6 -2    # -2はExcel行とdf行の調整 
iHarai_LT = 5   # 払出LT 

row_data_sta = 9 -2  # -2はExcel行とdf行の調整 

#日程一覧表のカレンダーの開始日を取得a
# date_start  = pd.to_timedelta(int(df_nittei.iloc[row_cal,col_cal]) -2, unit='D') + pd.to_datetime('1900/01/01')  #ExcelとPythonでは基準日からの数え方に違いがあるので2日ずらす
# print(date_start)

df_nittei =pd.merge(df_nittei,df_master,left_on=['型名','仕様']  ,right_on=['型名','仕様']  , how='left' )  #日程一覧表に 型名マスタの標準LTをleft join する 

df_cal = pd.read_excel('カレンダー.xlsx' , header=None )  #カレンダー取り込み。  オフセット日の計算用。 
df_cal = df_cal.fillna(0)    #休日のNaNはゼロ値をセットしておく。（実働日に１を立てている）

#区分U ﾕﾆｯﾄの部品納期自動を計算するb
for i in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
    if df_nittei.loc[i,'区分'] == 'U' :
        for j in range( col_cal ,  len(df_nittei.columns)):  #カレンダー部を右方向へ探索する 
            if type(df_nittei.iloc[i,j]) in (int,float)  :   # 数値型 int float の場合、  生産計画ありとみなす。
                date_sento  = pd.to_timedelta(int(df_nittei.iloc[row_cal,j]) -2, unit='D') + pd.to_datetime('1900/01/01')   #生産計画の先頭日を取得
                keisu = df_nittei.loc[i,'部品納期自動係数']
                if type(keisu) is str :   # 係数未入力の場合は fillnaで空文字を入れている。 文字型の場合は 係数1とする。 
                    keisu = 1
                offset_days = ( iHarai_LT + df_nittei.loc[i,'U標準LT'] ) * keisu *  -1     # オフセット日数 ＝ (払出LT＋標準LT ) * 係数 。   負の方向へのオフセットなので * -1 をかける。
                offset_days = int(offset_days)                                             #オフセット日数は整数とする
                date_offset = day_offset( df_cal, date_sento, offset_days  )               #オフセット日の計算。実働日計算
                df_nittei.loc[i,'部品納期自動'] =  date_offset                             #計算したオフセット日をdfにセットする 
                
                #print( f'  {i+2}   {j+1}   {df_nittei.iloc[i,j]}   { j - col_cal }  {date_sento}  オフセット： {offset_days}  {date_offset}  keisu:{keisu}  '  )    # +2はExcel行とdf行の調整 
                break   #オフセット日をセットしたので、break し次の行へ移る。 

#モジュールの部品納期自動の計算処理 step1   一旦 オーダ８桁の先頭日を取得する
for i in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
    if df_nittei.loc[i,'区分'] =='M':   #モジュールは一旦 生産計画の先頭日を取得する。 後で、 ｵｰﾀﾞ４桁ごとに最早の生産計画日をセットしなおす。 
        for j in range( col_cal ,  len(df_nittei.columns)):  #カレンダー部を右方向へ探索する 
            if  df_nittei.iloc[i,j] in ('組立','着手','ああ')  :   # モジュールの着手を表す文字列の場合
                date_sento  = pd.to_timedelta(int(df_nittei.iloc[row_cal,j]) -2, unit='D') + pd.to_datetime('1900/01/01')   #生産計画の先頭日を取得
                df_nittei.loc[i,'着手日'] = date_sento
                #print( f'  {i+2}   {j+1}   {df_nittei.iloc[i,j]}   { j - col_cal }  {date_sento}  着手日：{date_sento}  オーダ４桁 :{ df_nittei.iloc[i,1][0:4] }  '  )    # +2はExcel行とdf行の調整 
                break  

#モジュールの部品納期自動の計算処理 step2   オーダ４桁ごとの先頭日を計算する
for i in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
    if df_nittei.loc[i,'区分'] =='M':   #モジュールはｵｰﾀﾞ４桁ごとに最早の生産計画日をセットしなおす。 
        for i2 in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
            if df_nittei.loc[i,'オーダ'][0:4] == df_nittei.loc[i2,'オーダ'][0:4] :
                if df_nittei.loc[i,'着手日']  > df_nittei.loc[i2,'着手日'] :
                    df_nittei.loc[i,'着手日']  = df_nittei.loc[i2,'着手日']   

#モジュールの部品納期自動の計算処理 step3  最終
for i in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
    if df_nittei.loc[i,'区分'] =='M':   #モジュールはｵｰﾀﾞ４桁ごとの最早の生産計画日を基に部品納期自動をセットする 
        keisu = df_nittei.loc[i,'部品納期自動係数']
        if type(keisu) is str :   # 係数未入力の場合は fillnaで空文字を入れている。 文字型の場合は 係数1とする。 
            keisu = 1
        offset_days = iHarai_LT   * keisu *  -1     # オフセット日数 ＝ (払出LT ) * 係数 。   負の方向へのオフセットなので * -1 をかける。
        offset_days = int(offset_days)                                             #オフセット日数は整数とする
        date_offset = day_offset( df_cal, df_nittei.loc[i,'着手日'], offset_days  )               #オフセット日の計算。実働日計算
        df_nittei.loc[i,'部品納期自動'] =  date_offset                             #計算したオフセット日をdfにセットする 

        chakubi = df_nittei.loc[i,'着手日']
        #print( f'  {i+2}   {j+1}   {df_nittei.iloc[i,j]}   { j - col_cal }  {date_sento}  オフセット： {offset_days}  {date_offset}  keisu:{keisu}  着日： {chakubi}'   )    # +2はExcel行とdf行の調整 


# print( '部品納期自動  '  , df_nittei.columns.get_loc('部品納期自動'))  

col_buhinnoki_jido = df_nittei.columns.get_loc('部品納期自動')

#計算した部品納期自動を出力する
import openpyxl
from openpyxl.styles import PatternFill
from openpyxl.comments import Comment

wb = openpyxl.load_workbook(sTgtFile)
ws = wb["Sheet1"]

fill = PatternFill(patternType='solid', fgColor='99ffff')

for i in range(  row_data_sta, len(df_nittei)):  # 日程一覧表の行を順に処理していく 
    ws.cell(row=i+2, column=col_buhinnoki_jido+1).fill = PatternFill(fill_type = None)  #背景色を一旦クリア
    ws.cell(row=i+2, column=col_buhinnoki_jido+1).comment = None                        #コメントを一旦クリア

    if str(df_nittei.loc[i,'部品納期自動']) != str(df_nittei_back.loc[i,'部品納期自動']) :     #部品納期自動の変更があった場合
        ws.cell(row=i+2, column=col_buhinnoki_jido+1).value= df_nittei.loc[i,'部品納期自動']   #変更された 部品納期自動をセット
        ws.cell(row=i+2, column=col_buhinnoki_jido+1).number_format ='yyyy/mm/dd'             # 日付書式セット
        ws.cell(row=i+2, column=col_buhinnoki_jido+1).fill = fill                             #背景色をセット 
        ws.cell(row=i+2, column=col_buhinnoki_jido+1).comment = Comment('前回値：' + str(df_nittei_back.loc[i,'部品納期自動'].date()) , '' )   #コメントに前回値をセットする

        print( i+2  , '行目  '   , df_nittei.loc[i,'オーダ']  , '   変更前：' , df_nittei_back.loc[i,'部品納期自動'].date() ,'  変更後：'  ,   df_nittei.loc[i,'部品納期自動'].date()   )

wb.save(sTgtFile)
wb.close()


print('処理終了')
