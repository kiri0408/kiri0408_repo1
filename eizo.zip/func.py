import pandas as pd

def day_offset( df_cal, date_Kijun, iOffset  ):

    dt =  date_Kijun -  df_cal.iloc[0,0]   #基準日 - カレンダー開始日 の差分日数  
    j = dt.days                            # j = 差分日数の整数値 

    if iOffset == 0 :
        return date_Kijun

    elif iOffset > 0 :   #  正の方向へオフセットの場合
        sum = 0
        
        while sum <= iOffset :
            j+=1
            if j == len(df_cal.columns)-1:  #カレンダー範囲外へのオフセット はbreak
                return   
            
            sum +=  df_cal.iloc[1,j]
            if sum == iOffset :
                #print(j)
                return df_cal.iloc[0,j]
        
    elif iOffset < 0 :   #  負の方向へオフセットの場合
        sum = 0
        
        while sum >= iOffset :
            j-=1
            if j < 0 :  #カレンダー範囲外へのオフセットはbreak
                return

            sum -=  df_cal.iloc[1,j]
            if sum == iOffset :
                #print(j)
                return df_cal.iloc[0,j]


def isint(s):  # 整数値を表しているかどうかを判定
    try:
        int(s, 10)  # 文字列を実際にint関数で変換してみる
    except ValueError:
        return False  # 例外が発生＝変換できないのでFalseを返す
    else:
        return True  # 変換できたのでTrueを返す