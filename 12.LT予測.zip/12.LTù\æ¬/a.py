#サンプルデータの読み込み
from pycaret.datasets import get_data 
boston = get_data('boston')
 
#モデル探索に必要なパッケージのインポート
import pandas as pd
from pycaret.regression import *
 
#前処理を行う(データの指定と目的変数(=ターゲット) のカラム名を指定）
setup(data=boston,target='crim')
 
#複数のモデルを試し、成績が一番良いモデルを取得
model = compare_models()
 
#取得したモデルに対してハイパーパラメータを自動探索
tuned_model = tune_model(model)
 
#ハイパーパラメータ調整後のモデルに対して、精度を把握するためのグラフを表示
evaluate_model(tuned_model)
 
#与えられた全ての教師データを使ってモデルを最終版の作成
final_model = finalize_model
 
#出来上がった最終版のモデルをファイルに書き出す
save_model(final_model,r'.\finalmodel')