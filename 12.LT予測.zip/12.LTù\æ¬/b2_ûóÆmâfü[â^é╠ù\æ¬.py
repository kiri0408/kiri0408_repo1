# coding: UTF-8
# パッケージの読み込み
import pandas as pd
from pycaret.regression import *

#未知なるデータを読み込む
data_unseen = pd.read_excel('data_test.xlsx')
print(data_unseen)

# finalmodel.pkl というモデルファイルを読み込む
final_model5 = load_model('finalmodel')

unseen_predictions = predict_model(final_model5, data = data_unseen)
print(unseen_predictions)

#CSVファイルでダウンロードする
unseen_predictions.to_excel('data_predicted.xlsx')