import torch
import torch.nn as nn
from torchvision import  models, transforms
from zmq import device
import pathlib
import shutil
#device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
device = torch.device('cpu')
 

#====== モデル(ネットワーク)　設定======
model = models.resnet18(pretrained=True)  #学習済みの重みももってくる
model.fc = nn.Linear(512, 3)   ##モデルの最後のfcを付け替える。  分類する数に合わせる！！

#====== ロード =======
model.load_state_dict(torch.load("model.pth", map_location=device))
 
#====== 推論 ======
model.eval()                     # switch to inference mode   予測モードにしておく！   
from PIL import Image

label = ['岸田さん','安部さん','高市さん']

def eval(file):
    preprocess = transforms.Compose([
    transforms.Resize((224, 224)),  #画像サイズバラバラなのをリサイズ
    transforms.ToTensor(),                 #画像をtensorクラスに変換 チャネルファーストへ入れ替えと値を０－１へ。
    transforms.Normalize((0.5,), (0.5,))   #平均と標準偏差を０．５になるように正規化                               
    ])
    img_org = Image.open(file)
    img = preprocess(img_org)
    img_batch = img[None]  # PyTorchではバッチ処理が基本なので、1枚の画像の場合も先頭に次元を追加する必要がある。
    output = model(img_batch)   #予測を行う
    #print(output)
    idx = torch.argmax(output, dim=1)
    idx = int(idx.to('cpu'))
    print(f'{file}  = {label[idx]}  ')
    return idx


#フォルダ内の各ファイルについて予測
fol = './data_eval/'
p_temp = pathlib.Path(fol).glob('*.jpg')  #指定フォルダ内のファイル名をリストに取得
for p in p_temp:
    idx = eval(fol + p.name)  #予測

    #予測された番号のフォルダへ画像を移動
    # source = fol + p.name
    # destination = fol + str(idx) + '/'  + p.name
    # shutil.move(source,destination)

