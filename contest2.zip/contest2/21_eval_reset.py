import os
import shutil

path_dir = "./data_eval/"

for i in range(3):

    list_file_name =  os.listdir(path_dir + str(i))

    for i_file_name in list_file_name:
        
        join_path = os.path.join(path_dir + str(i),i_file_name)
        move_path = os.path.join(path_dir,i_file_name)

        if os.path.isfile(join_path):
            shutil.move(join_path,move_path)