﻿Imports Microsoft.Office.Interop


Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    '実績をEXCELに登録／更新する 
    Private Function ExcelUpd(ByVal ord1 As String, ByVal suryo1 As Int16, ByVal bookname As String, ByVal sheetname As String) As Boolean

        Dim xlApp As Excel.Application
        Try
            xlApp = DirectCast(System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application"), Excel.Application)
        Catch ex As Exception
            MessageBox.Show("Excelが起動していません。\n" & ex.Message)
            Return False
        End Try

        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim LastRow As Long

        Dim dt1 As DateTime = DateTime.Now
        Dim rireki_date As String
        Dim rireki_ord As String
        Dim upd_flg As Int16

        Try

            Try
                ' EXCELシートをセット
                xlBook = xlApp.Workbooks(bookname)
                xlSheet = xlBook.Worksheets(sheetname)
            Catch ex As Exception
                MessageBox.Show("Excelシートが見つかりません  " & bookname & "    " & sheetname)

                Return False
            End Try

            LastRow = xlSheet.Cells(10000, 1).End(-4162).Row   '-4162 xlUP  最終行を求める

            Dim i As Int16
            i = LastRow
            upd_flg = 0

            '日時文字列とオーダがすでに存在する場合は更新。 数量を加算する。
            While i >= 1

                rireki_date = xlSheet.Cells(i, 10).Value  '10列目の日時を表す文字列 yyyy/mm/dd HH を取得 
                rireki_ord = xlSheet.Cells(i, 3).Value    '3列目のオーダを取得


                If dt1.ToString("yyyy/MM/dd HH") = rireki_date And ord1 = rireki_ord Then
                    xlSheet.Cells(i, 4).Value += suryo1
                    xlSheet.Cells(i, 11).Value = dt1
                    upd_flg = 1
                    Exit While
                End If

                If dt1.ToString("yyyy/MM/dd HH") <> rireki_date Then
                    Exit While
                End If

                i = i - 1

            End While

            '日時文字列とオーダが存在しない場合は、行追加
            If upd_flg = 0 Then '
                xlSheet.Cells(LastRow + 1, 1).Value = dt1.ToString("yyyy/MM/dd")
                xlSheet.Cells(LastRow + 1, 2).Value = dt1.ToString("HH")
                xlSheet.Cells(LastRow + 1, 3).Value = ord1
                xlSheet.Cells(LastRow + 1, 4).Value = suryo1
                xlSheet.Cells(LastRow + 1, 10).Value = dt1.ToString("yyyy/MM/dd HH")
                xlSheet.Cells(LastRow + 1, 11).Value = dt1
            End If


        Finally
            ' 解放処理
            For Each comObj As Object In New Object() {xlSheet, xlBook}
                If (comObj IsNot Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(comObj)
                End If
            Next
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
        End Try

        Return True

    End Function


    '登録した実績の取り消し。  数量をマイナスする。  
    Private Function ExcelDel(ByVal ord1 As String, ByVal suryo1 As Int16, ByVal date_hour1 As String, ByVal bookname As String, ByVal sheetname As String) As Boolean

        Dim xlApp As Excel.Application
        Try
            xlApp = DirectCast(System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application"), Excel.Application)
        Catch ex As Exception
            MessageBox.Show("Excelが起動していません。\n" & ex.Message)
            Return False
        End Try


        Dim xlBook As Excel.Workbook = Nothing
        Dim xlSheet As Excel.Worksheet = Nothing
        Dim LastRow As Long

        Dim dt1 As DateTime = DateTime.Now
        Dim rireki_date As String
        Dim rireki_ord As String


        Try

            Try
                ' 先頭のシートのA1セルに文字列を書き込みます。
                xlBook = xlApp.Workbooks(bookname)
                xlSheet = xlBook.Worksheets(sheetname)
            Catch ex As Exception
                MessageBox.Show("Excelシートが見つかりません  " & bookname & "    " & sheetname)

                Return False
            End Try

            LastRow = xlSheet.Cells(10000, 1).End(-4162).Row   '-4162 xlUP

            Dim i As Int16
            i = LastRow

            ' 日時とオーダが一致する行から、数量をマイナスする
            While i >= 1

                rireki_date = xlSheet.Cells(i, 10).Value   '10列目の日時を表す文字列 yyyy/mm/dd HH を取得
                rireki_ord = xlSheet.Cells(i, 3).Value     '3列目のオーダを取得

                If date_hour1 = rireki_date And ord1 = rireki_ord Then
                    xlSheet.Cells(i, 4).Value -= suryo1    '生産数の取り消し 

                    If xlSheet.Cells(i, 4).Value < 0 Then  '生産数がマイナスは無いので、マイナスの場合はゼロにする。  
                        xlSheet.Cells(i, 4).Value = 0
                    End If

                    xlSheet.Cells(i, 11).Value = dt1       '更新日時のセット 

                    Exit While
                End If

                If i < LastRow - 100 Or i = 1 Then                 '最大１００行チェックする。  オンライン画面は最大でも５０行
                    MessageBox.Show("Excelシートに削除対象の実績データがありません")
                    Exit While
                End If

                i = i - 1

            End While


        Finally
            ' 解放処理
            For Each comObj As Object In New Object() {xlSheet, xlBook}
                If (comObj IsNot Nothing) Then
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(comObj)
                End If
            Next
            System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp)
        End Try

        Return True

    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ExcelUpd("ord31", 3, "test2.xlsx", "実績データ")


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ExcelDel("ord22", 1, "2023/01/07 19", "test2.xlsx", "実績データ")
    End Sub
End Class
